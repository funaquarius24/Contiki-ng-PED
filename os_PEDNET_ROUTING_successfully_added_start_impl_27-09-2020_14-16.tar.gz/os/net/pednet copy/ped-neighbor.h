/*
 * Copyright (c) 2010, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 *
 */

 /**
 * \addtogroup ped
 * @{
 *
 * \file
 *	Header file for ped-neighbor module
 * \author
 *	Joakim Eriksson <joakime@sics.se>, Nicolas Tsiftes <nvt@sics.se>,
 *  Simon DUquennoy <simon.duquennoy@inria.fr>
 *
 */

#ifndef PED_NEIGHBOR_H
#define PED_NEIGHBOR_H

/********** Includes **********/

#include "net/routing/ped/ped.h"
#include "lib/list.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/uip-ds6.h"
#include "sys/ctimer.h"

/********** Public symbols **********/

/* Per-neighbor PED information. According to RFC 6550, there exist three
 * types of neighbors:
 * - Candidate neighbor set: any neighbor, selected in an implementation
 * and OF-specific way. The nodes in ped_neighbors constitute the candidate neighbor set.
 * - Parent set: the subset of the candidate neighbor set with rank below our rank
 * - Preferred parent: one node of the parent set
 */
NBR_TABLE_DECLARE(ped_neighbors);

/********** Public functions **********/

/**
 * Initialize ped-dag-neighbor module
*/
void ped_neighbor_init(void);

/**
 * Tells wether we have fresh link information towards a given neighbor
 *
 * \param nbr The neighbor
 * \return 1 if we have fresh link information, 0 otherwise
*/
int ped_neighbor_is_fresh(ped_nbr_t *nbr);

/**
 * Tells wether we a given neighbor is reachable
 *
 * \param nbr The neighbor
 * \return 1 if the parent is reachable, 0 otherwise
*/
int ped_neighbor_is_reachable(ped_nbr_t *nbr);


/**
 * Returns a neighbors's link-layer address
 *
 * \param nbr The neighbor
 * \return The link-layer address if any, NULL otherwise
*/
const linkaddr_t *ped_neighbor_get_lladdr(ped_nbr_t *nbr);

/**
 * Returns a neighbor's link statistics
 *
 * \param nbr The neighbor
 * \return The link_stats structure address if any, NULL otherwise
*/
const struct link_stats *ped_neighbor_get_link_stats(ped_nbr_t *nbr);

/**
 * Returns a neighbor's (link-local) IPv6 address
 *
 * \param nbr The neighbor
 * \return The link-local IPv6 address if any, NULL otherwise
*/
uip_ipaddr_t *ped_neighbor_get_ipaddr(ped_nbr_t *nbr);

/**
 * Returns a neighbor from its link-layer address
 *
 * \param addr The link-layer address
 * \return The neighbor if found, NULL otherwise
*/
ped_nbr_t *ped_neighbor_get_from_lladdr(uip_lladdr_t *addr);

/**
 * Returns a neighbor from its link-local IPv6 address
 *
 * \param addr The link-local IPv6 address
 * \return The neighbor if found, NULL otherwise
*/
ped_nbr_t *ped_neighbor_get_from_ipaddr(uip_ipaddr_t *addr);

/**
 * Returns the number of nodes in the PED neighbor table
 *
 * \return the neighbor count
*/
int ped_neighbor_count(void);

/**
 * Prints a summary of all PED neighbors and their properties
 *
 * \param str A descriptive text on the caller
*/
void ped_neighbor_print_list(const char *str);

/**
 * Empty the PED neighbor table
*/
void ped_neighbor_remove_all(void);


/**
* Print a textual description of PED neighbor into a string
*
* \param buf The buffer where to write content
* \param buflen The buffer len
* \param nbr A pointer to a PED neighbor that will be written to the buffer
* \return Identical to snprintf: number of bytes written excluding ending null
* byte. A value >= buflen if the buffer was too small.
*/
int ped_neighbor_snprint(char *buf, int buflen, ped_nbr_t *nbr);

 /** @} */

#endif /* PED_NEIGHBOR_H */
