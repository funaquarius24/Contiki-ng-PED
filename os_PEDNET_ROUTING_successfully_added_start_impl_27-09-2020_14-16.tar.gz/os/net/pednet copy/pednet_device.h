/*******************************************
 * 
 * 
 * 
 * 
 * **********************************************/

#ifndef PED_DEVICE_H
#define PED_DEVICE_H

#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/uip-ds6-nbr.h"
#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-sr.h"
#include "net/linkaddr.h"


struct pednet_device_driver
{
    char *name;
    void (* init)(void);
    int (* root_start)(void);
    int (* node_is_ER)(void);
    int (* node_is_R)(void);
    int (*node_is_leaf)(void);
};















#endif