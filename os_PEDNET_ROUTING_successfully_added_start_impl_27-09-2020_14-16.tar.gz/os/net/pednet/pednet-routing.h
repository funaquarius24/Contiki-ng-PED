/*******************************************
 * 
 * 
 * 
 * 
 * **********************************************/ 

#ifndef PEDNET_ROUTING_H
#define PEDNET_ROUTING_H

#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/uip-ds6-nbr.h"
#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-sr.h"
#include "net/linkaddr.h"


struct pednet_driver
{
    char *name;
    void (* init)(void);
    int (* root_start)(void);
    int (* node_is_ER)(void);
    int (* node_is_R)(void);
    int (* node_is_leaf)(void);
    void (* set_prefix)(uip_ipaddr_t *prefix, uip_ipaddr_t *iid);
    int (* get_root_ipaddr)(uip_ipaddr_t *ipaddr);
    void (* leave_network)(void);
    int (* node_has_joined)(void);
    int (* node_is_reachable)(void);
    void (* link_callback)(const linkaddr_t *addr, int status, int numtx);
    void (* neighbor_state_changed)(uip_ds6_nbr_t *nbr);
    void (* drop_route)(uip_ds6_route_t *route);

};

//extern const struct pednet_driver PEDNET_ROUTING;
















#endif