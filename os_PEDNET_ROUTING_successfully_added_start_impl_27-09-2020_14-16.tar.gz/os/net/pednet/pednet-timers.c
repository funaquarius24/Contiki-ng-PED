/*
 * Copyright (c) 2010, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 */

/**
 * \addtogroup ped
 * @{
 *
 * \file
 *         RPL timer management.
 *
 * \author Joakim Eriksson <joakime@sics.se>, Nicolas Tsiftes <nvt@sics.se>,
 * Simon Duquennoy <simon.duquennoy@inria.fr>
 */

#include "contiki.h"

#include "net/ipv6/uip-sr.h"
#include "net/link-stats.h"
#include "lib/random.h"
#include "sys/ctimer.h"

/* Log configuration */
#include "sys/log.h"
#define LOG_MODULE "PED"
#define LOG_LEVEL LOG_LEVEL_PED

/* A configurable function called after update of the RPL DIO interval */
#ifdef RPL_CALLBACK_NEW_DIO_INTERVAL
void RPL_CALLBACK_NEW_DIO_INTERVAL(clock_time_t dio_interval);
#endif /* RPL_CALLBACK_NEW_DIO_INTERVAL */

#ifdef RPL_PROBING_SELECT_FUNC
ped_nbr_t *RPL_PROBING_SELECT_FUNC(void);
#endif /* RPL_PROBING_SELECT_FUNC */

#ifdef RPL_PROBING_DELAY_FUNC
clock_time_t RPL_PROBING_DELAY_FUNC(void);
#endif /* RPL_PROBING_DELAY_FUNC */

#define PERIODIC_DELAY_SECONDS     60
#define PERIODIC_DELAY             ((PERIODIC_DELAY_SECONDS) * CLOCK_SECOND)
#define R_INIT_DELAY               (20 * CLOCK_SECOND) /* Number of seconds * clock_second */
#define ER_INIT_DELAY              (20 * CLOCK_SECOND) /* Number of seconds * clock_second */
#define N_MAX_DELAY                100

#define NODE_NEW_DELAY             (20 * CLOCK_SECOND) /* Number of seconds * clock_second */
#define ROUTER_NEW_DELAY           (20 * CLOCK_SECOND) /* Number of seconds * clock_second */




static void handle_node_new_timer(void *ptr);
static void handle_router_new_timer(void *ptr);
static void handle_router_new_ack_timer(void *ptr);
static void handle_node_new_ack_timer(void *ptr);
static void handle_eap_timer(void *ptr);
static void handle_rap_timer(void *ptr);


static void handle_periodic_timer(void *ptr);
//static void handle_state_update(void *ptr);

/*---------------------------------------------------------------------------*/
//static struct ctimer dis_timer; /* Not part of a DAG because when not joined */
static struct ctimer periodic_timer; /* Not part of a DAG because used for general state maintenance */


static struct ctimer node_new_timer; /* ism timer for sending new node */
// static struct ctimer router_new_timer = {}; /* ism timer for sending router node */
// static struct ctimer ER_init_timer = {};
// static struct ctimer R_initialization_timer = {};
// static struct ctimer N_initialization_timer = {};
// static struct ctimer N_check_timer = {};
// static struct ctimer R_addr_config_timer = {};
// static struct ctimer ER_addr_config_timer = {};

// static bool node_connected;
// static bool router_connected;


void
ped_timers_schedule_periodic_node_new(void)
{
  LOG_INFO("sCHEDULE Node New");
  if(ctimer_expired(&node_new_timer)) {
    clock_time_t expiration_time = NODE_NEW_DELAY / 2 + (random_rand() % (NODE_NEW_DELAY));
    ctimer_set(&node_new_timer, expiration_time, handle_node_new_timer, NULL);
  }
}

void
ped_timers_schedule_periodic_router_new(void)
{
}

/*---------------------------------------------------------------------------*/
static void
handle_node_new_timer(void *ptr)
{
  LOG_INFO("REACHED .....Node New.......\n");
  clock_time_t expiration_time = NODE_NEW_DELAY / 2 + (random_rand() % (NODE_NEW_DELAY));
    ctimer_set(&node_new_timer, expiration_time, handle_node_new_timer, NULL);

}

static void
handle_router_new_timer(void *ptr)
{
  LOG_INFO("REACHED .....Router New.......\n");
}

static void
handle_router_new_ack_timer(void *ptr)
{
  LOG_INFO("REACHED .....Router New.......\n");
}

static void
handle_node_new_ack_timer(void *ptr)
{
  LOG_INFO("REACHED .....Router New.......\n");
}

static void
handle_eap_timer(void *ptr)
{
  LOG_INFO("REACHED .....Router New.......\n");
}

static void
handle_rap_timer(void *ptr)
{
  LOG_INFO("REACHED .....Router New.......\n");
}

static void
handle_periodic_timer(void *ptr)
{
  LOG_INFO("PERIODIC TIMER");

  //ctimer_reset(&periodic_timer);
}

void
ped_timers_init(void)
{
  LOG_INFO("INIT");

  ctimer_set(&periodic_timer, PERIODIC_DELAY, handle_periodic_timer, NULL);
  ped_timers_schedule_periodic_node_new();
  //ped_timers_schedule_periodic_router_new();

  handle_node_new_timer(NULL);
  handle_router_new_timer(NULL);
  handle_router_new_ack_timer(NULL);
  handle_node_new_ack_timer(NULL);
  handle_eap_timer(NULL);
  handle_rap_timer(NULL);


}

/** @}*/
