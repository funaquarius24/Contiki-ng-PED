/*
 * Copyright (c) 2010, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 *
 */

/**
 * \addtogroup ped
 * @{
 *
 * \file
 *         Logic for DAG neighbors in PED.
 *
 * \author Joakim Eriksson <joakime@sics.se>, Nicolas Tsiftes <nvt@sics.se>,
 * Simon Duquennoy <simon.duquennoy@inria.fr>
 * Contributors: George Oikonomou <oikonomou@users.sourceforge.net> (multicast)
 */

#include "contiki.h"
#include "net/routing/ped/ped.h"
#include "net/link-stats.h"
#include "net/nbr-table.h"
#include "net/ipv6/uiplib.h"

/* Log configuration */
#include "sys/log.h"
#define LOG_MODULE "PED"
#define LOG_LEVEL LOG_LEVEL_PED

/* A configurable function called after every PED parent switch */
#ifdef PED_CALLBACK_PARENT_SWITCH
void PED_CALLBACK_PARENT_SWITCH(ped_nbr_t *old, ped_nbr_t *new);
#endif /* PED_CALLBACK_PARENT_SWITCH */

static ped_nbr_t * best_parent(int fresh_only);

/*---------------------------------------------------------------------------*/
/* Per-neighbor PED information */
NBR_TABLE_GLOBAL(ped_nbr_t, ped_neighbors);

/*---------------------------------------------------------------------------*/
int
ped_neighbor_snprint(char *buf, int buflen, ped_nbr_t *nbr)
{
  return 0;
}
/*---------------------------------------------------------------------------*/
void
ped_neighbor_print_list(const char *str)
{
  
}
/*---------------------------------------------------------------------------*/
int
ped_neighbor_count(void)
{
  int count = 0;
  ped_nbr_t *nbr = nbr_table_head(ped_neighbors);
  for(nbr = nbr_table_head(ped_neighbors);
      nbr != NULL;
      nbr = nbr_table_next(ped_neighbors, nbr)) {
    count++;
  }
  return count;
}
/*---------------------------------------------------------------------------*/
static void
remove_neighbor(ped_nbr_t *nbr)
{
  nbr_table_remove(ped_neighbors, nbr);
  ped_timers_schedule_state_update(); /* Updating from here is unsafe; postpone */
}
/*---------------------------------------------------------------------------*/
ped_nbr_t *
ped_neighbor_get_from_lladdr(uip_lladdr_t *addr)
{
  return nbr_table_get_from_lladdr(ped_neighbors, (linkaddr_t *)addr);
}
/*---------------------------------------------------------------------------*/
const linkaddr_t *
ped_neighbor_get_lladdr(ped_nbr_t *nbr)
{
  return nbr_table_get_lladdr(ped_neighbors, nbr);
}
/*---------------------------------------------------------------------------*/
uip_ipaddr_t *
ped_neighbor_get_ipaddr(ped_nbr_t *nbr)
{
  const linkaddr_t *lladdr = ped_neighbor_get_lladdr(nbr);
  return uip_ds6_nbr_ipaddr_from_lladdr((uip_lladdr_t *)lladdr);
}
/*---------------------------------------------------------------------------*/
const struct link_stats *
ped_neighbor_get_link_stats(ped_nbr_t *nbr)
{
  const linkaddr_t *lladdr = ped_neighbor_get_lladdr(nbr);
  return link_stats_from_lladdr(lladdr);
}
/*---------------------------------------------------------------------------*/
int
ped_neighbor_is_fresh(ped_nbr_t *nbr)
{
  const struct link_stats *stats = ped_neighbor_get_link_stats(nbr);
  return link_stats_is_fresh(stats);
}
/*---------------------------------------------------------------------------*/
int
ped_neighbor_is_reachable(ped_nbr_t *nbr) {
  if(nbr == NULL) {
    return 0;
  } else {
    /* If we don't have fresh link information, assume the nbr is reachable. */
    return !ped_neighbor_is_fresh(nbr);
  }
}

/*---------------------------------------------------------------------------*/
/* Remove all DAG neighbors */
void
ped_neighbor_remove_all(void)
{
  ped_nbr_t *nbr;

  LOG_INFO("removing all neighbors\n");

  /* Unset preferred parent before we de-allocate it. This will set
   * unprocessed_parent_switch which will make sure ped_dag_update_state takes
   * all actions necessary after losing the preferred parent */

  nbr = nbr_table_head(ped_neighbors);
  while(nbr != NULL) {
    remove_neighbor(nbr);
    nbr = nbr_table_next(ped_neighbors, nbr);
  }

  /* Update needed immediately. As we have lost the preferred parent this will
   * enter poisoining and set timers accordingly. */
  ped_dag_update_state();
}
/*---------------------------------------------------------------------------*/
ped_nbr_t *
ped_neighbor_get_from_ipaddr(uip_ipaddr_t *addr)
{
  uip_ds6_nbr_t *ds6_nbr = uip_ds6_nbr_lookup(addr);
  const uip_lladdr_t *lladdr = uip_ds6_nbr_get_ll(ds6_nbr);
  return nbr_table_get_from_lladdr(ped_neighbors, (linkaddr_t *)lladdr);
}
/*---------------------------------------------------------------------------*/
void
ped_neighbor_init(void)
{
  nbr_table_register(ped_neighbors, (nbr_table_callback *)remove_neighbor);
}
/** @} */
