#ifndef PEDNET_ER_H
#define PEDNET_ER_H

void 
ped_er_init(void);

int 
ped_er_start();

void
ped_er_set_prefix(uip_ipaddr_t *prefix, uip_ipaddr_t *iid);

void
set_global_address(uip_ipaddr_t *prefix, uip_ipaddr_t *iid);








#endif