#include "contiki.h"
#include "net/packetbuf.h"
#include "net/netstack.h"

#include "net/pednet/pednet.h"
#include "net/pednet/pednet-conf.h"
#include "net/pednet/pednet-timers.h"
#include "net/pednet/pednet-routing.h"
#include "net/pednet/pednet-er.h"

/* Log configuration */
#include "sys/log.h"
#define LOG_MODULE "PED"
#define LOG_LEVEL LOG_LEVEL_PED

//static 
void 
init(){
  #if PED_ER
    ped_er_init();
  #elif PED_R
    ped_r_init();
  #elif PED_LEAF
    ped_leaf_init();
  #endif
  ped_timers_init();
    
}


//static 
int
ped_node_is_er(void){
  if (PED_ER){
    return 1;
  }

  return 0;
  
}

//static 
int
ped_node_is_r(void){
  return PED_R ? 1 : 0;
}

//static 
int
ped_node_is_leaf(void){
  if (PED_LEAF){
    return 1;
  }

  return 0;
  
}

int
ped_get_er_ipaddr(uip_ipaddr_t *ipaddr)
{
  return 0;
}

const uip_ipaddr_t *
ped_get_global_address(void)
{
  LOG_INFO("gET GLOBAL ADDR");

  
  return NULL;
}
/*---------------------------------------------------------------------------*/
void
ped_link_callback(const linkaddr_t *addr, int status, int numtx)
{
  
      /* Link stats were updated, and we need to update our internal state.
      Updating from here is unsafe; postpone */
      LOG_INFO("packet sent to ");
      LOG_INFO_LLADDR(addr);
      
    
  
}
/*---------------------------------------------------------------------------*/
int
ped_node_has_joined(void)
{
  return 0;
}
/*---------------------------------------------------------------------------*/
int
ped_node_is_reachable(void)
{
  return 0;
}

void 
ped_leave_network(void){

}

//static 
void
neighbor_state_changed(uip_ds6_nbr_t *nbr)
{
  /* Nothing needs be done in non-storing mode */
}

//static 
void
drop_route(uip_ds6_route_t *route)
{
  /* Do nothing. RPL-lite only supports non-storing mode, i.e. no routes */
}
