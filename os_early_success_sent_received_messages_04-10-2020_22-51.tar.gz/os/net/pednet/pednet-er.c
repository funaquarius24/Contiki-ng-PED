/*****************************************************************************
 * 
 * 
 * 
 * 
 * 
 * ****************************************************************************/


#include "contiki.h"
#include "contiki-net.h"


#include "net/pednet/pednet.h"
#include "net/pednet/pednet-conf.h"
#include "net/pednet/pednet-const.h"
#include "net/pednet/pednet-types.h"
#include "net/pednet/pednet-timers.h"
#include "net/pednet/pednet-routing.h"
#include "net/pednet/pednet-er.h"
#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-sr.h"


/* Log configuration */
#include "sys/log.h"
#define LOG_MODULE "PED"
#define LOG_LEVEL LOG_LEVEL_PED

// hhhhh
pednet_instance_t curr_pednet_instance;

static void router_new_input(void);
static void node_failed_input(void);
static void node_mobile_input(void);
static void node_unreachable_input(void);
static void router_alive_input(void);
static void router_unreachable_input(void);

PED_HANDLER(router_new_handler, PED_MESSAGES, PED_CODE_ROUTER_NEW, router_new_input);
PED_HANDLER(node_failed_handler, PED_MESSAGES, PED_FAIL_NODE_FAILED, node_failed_input);
PED_HANDLER(node_mobile_handler, PED_MESSAGES, PED_FAIL_NODE_MOBILE, node_mobile_input);
PED_HANDLER(node_unreachable_handler, PED_FAIL_DETECT, PED_FAIL_NODE_UNREACHABLE, node_unreachable_input);
PED_HANDLER(router_alive_handler, PED_FAIL_DETECT, PED_FAIL_ROUTER_ALIVE, router_alive_input);
PED_HANDLER(router_unreachable_handler, PED_FAIL_DETECT, PED_FAIL_ROUTER_UNREACHABLE, router_unreachable_input);



void 
ped_er_init(void){
  LOG_INFO("ER INIT REACHED");

  ped_timers_init();
  //curr_pednet_instance = NULL;
  ped_register_input_handler(&router_new_handler);
  ped_register_input_handler(&node_failed_handler);
  ped_register_input_handler(&node_mobile_handler);
  ped_register_input_handler(&node_unreachable_handler);
  ped_register_input_handler(&router_alive_handler);
  ped_register_input_handler(&router_unreachable_handler);

    
}

static void 
router_new_input()
{

}
void
node_failed_input(){}
void
node_mobile_input(){}
void
node_unreachable_input(){}
void 
router_alive_input(){}
void
router_unreachable_input(){}


/*---------------------------------------------------------------------------*/
void
ped_er_set_prefix(uip_ipaddr_t *prefix, uip_ipaddr_t *iid)
{
  static uint8_t initialized = 0;

  if(!initialized) {
    ped_set_global_address(prefix, iid);
    initialized = 1;
  }
}
/*---------------------------------------------------------------------------*/
int
ped_er_start(void)
{

  return 0;

  
}



const struct pednet_driver pednet_er_routing_driver = {
    "PEDNET_ER",
    ped_er_init,
    ped_er_start,
    ped_node_is_er,
    ped_node_is_r,
    ped_node_is_leaf,
    ped_er_set_prefix,
    ped_get_er_ipaddr,
    ped_leave_network,
    ped_node_has_joined,
    ped_node_is_reachable,
    ped_link_callback,
    neighbor_state_changed,
    drop_route,

};
