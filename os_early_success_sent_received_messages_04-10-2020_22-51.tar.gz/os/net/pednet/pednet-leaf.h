#ifndef PEDNET_LEAF_H
#define PEDNET_LEAF_H



void ped_leaf_init(void);
void node_new_output(void);



















#endif
