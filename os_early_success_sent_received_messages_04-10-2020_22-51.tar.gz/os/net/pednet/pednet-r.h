#ifndef PEDNET_R_H
#define PEDNET_R_H



void
ped_r_init(void);










#endif