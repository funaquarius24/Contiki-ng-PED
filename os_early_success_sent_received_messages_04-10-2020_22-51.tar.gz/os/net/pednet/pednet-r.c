/*****************************************************************************
 * 
 * 
 * 
 * 
 * 
 * ****************************************************************************/


#include "contiki.h"
#include "contiki-net.h"


#include "net/pednet/pednet.h"
#include "net/pednet/pednet-conf.h"
#include "net/pednet/pednet-const.h"
#include "net/pednet/pednet-types.h"
#include "net/pednet/pednet-timers.h"
#include "net/pednet/pednet-r.h"
#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-sr.h"
#include "net/pednet/pednet-routing.h"

/* Log configuration */
#include "sys/log.h"
#define LOG_MODULE "PED"
#define LOG_LEVEL LOG_LEVEL_PED

// hhhhh
pednet_instance_t curr_pednet_instance;

static void node_new_input(void);
static void router_new_ack_input(void);
static void er_addr_param_input(void);
static void node_alive_input(void);
static void node_unreachable_input(void);
static void node_mobile_input(void);
static void router_unreachable_input(void);

PED_HANDLER(node_new_handler, PED_MESSAGES, PED_CODE_NODE_NEW, node_new_input);
PED_HANDLER(router_new_ack_handler, PED_MESSAGES, PED_CODE_ROUTER_NEW_ACK, router_new_ack_input);
PED_HANDLER(er_addr_param_handler, PED_MESSAGES, PED_CODE_ER_ADDR_PARAM, er_addr_param_input);
PED_HANDLER(node_alive_handler, PED_FAIL_DETECT, PED_FAIL_NODE_ALIVE, node_alive_input);
PED_HANDLER(node_unreachable_handler, PED_FAIL_DETECT, PED_FAIL_NODE_UNREACHABLE, node_unreachable_input);
PED_HANDLER(node_mobile_handler, PED_FAIL_DETECT, PED_FAIL_NODE_MOBILE, node_mobile_input);
PED_HANDLER(router_unreachable_handler, PED_FAIL_DETECT, PED_FAIL_ROUTER_UNREACHABLE, router_unreachable_input);



void 
ped_r_init(void){
  LOG_INFO("R INIT REACHED \n");

  ped_timers_init();
  //curr_pednet_instance = NULL;
  ped_register_input_handler(&node_new_handler);
  ped_register_input_handler(&router_new_ack_handler);
  ped_register_input_handler(&er_addr_param_handler);
  ped_register_input_handler(&node_alive_handler);
  ped_register_input_handler(&node_unreachable_handler);
  ped_register_input_handler(&node_mobile_handler);
  ped_register_input_handler(&router_unreachable_handler);

    
}

void 
router_new_ack_input()
{

}
void
node_alive_input(){}
static void
node_new_input(){
  LOG_INFO("Node new received");
}
void
er_addr_param_input(){}
void
node_mobile_input(){}
void
node_unreachable_input(){}
void
router_unreachable_input(){}

/*---------------------------------------------------------------------------*/
void
ped_r_set_prefix(uip_ipaddr_t *prefix, uip_ipaddr_t *iid)
{
  static uint8_t initialized = 0;

  if(!initialized) {
    ped_set_global_address(prefix, iid);
    initialized = 1;
  }
}
/*---------------------------------------------------------------------------*/
int
ped_r_start(void)
{
  //struct uip_ds6_addr *root_if;
  //int i;
  //uint8_t state;
  //uip_ipaddr_t *ipaddr = NULL;

  //ped_r_set_prefix(NULL, NULL);

  return 0;

  
}

const struct pednet_driver pednet_r_routing_driver = {
    "PEDNET_R",
    ped_r_init,
    ped_r_start,
    ped_node_is_er,
    ped_node_is_r,
    ped_node_is_leaf,
    ped_r_set_prefix,
    ped_get_er_ipaddr,
    ped_leave_network,
    ped_node_has_joined,
    ped_node_is_reachable,
    ped_link_callback,
    neighbor_state_changed,
    drop_route,

};
