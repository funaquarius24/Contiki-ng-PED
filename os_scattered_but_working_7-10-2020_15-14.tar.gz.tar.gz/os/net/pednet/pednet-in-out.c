#include "net/pednet/pednet-in-out.h"

void
router_unreachable_input(){
    
}