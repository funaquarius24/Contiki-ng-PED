#ifndef PEDNET_R_H
#define PEDNET_R_H



void
ped_r_init(void);

void
ped_r_addr_param_output(uip_ipaddr_t *addr);

void 
ped_router_new_output(uip_ipaddr_t *addr);








#endif