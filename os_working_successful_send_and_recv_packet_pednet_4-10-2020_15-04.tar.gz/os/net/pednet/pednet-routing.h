/*******************************************
 * 
 * 
 * 
 * 
 * **********************************************/ 

#ifndef PEDNET_ROUTING_H
#define PEDNET_ROUTING_H

#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/uip-ds6-nbr.h"
#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-sr.h"
#include "net/linkaddr.h"

#include "net/pednet/pednet-types.h"


#define PED_HANDLER(name, type, code, func) \
  static pednet_input_handler_t name = { NULL, type, code, func }

void test_send();

void
ped_send(const uip_ipaddr_t *dest, int type, int code, int payload_len);

// static 
int ped_node_is_er(void);

//static 
int
ped_node_is_r(void);

//static 
int
ped_node_is_leaf(void);

uint8_t
ped_input(uint8_t type, uint8_t icode);


void
ped_register_input_handler(pednet_input_handler_t *handler);


const uip_ipaddr_t *
ped_get_global_address(void);
/*---------------------------------------------------------------------------*/
void
ped_link_callback(const linkaddr_t *addr, int status, int numtx);
/*---------------------------------------------------------------------------*/
int
ped_node_has_joined(void);
/*---------------------------------------------------------------------------*/
int
ped_node_is_reachable(void);

int 
ped_get_er_ipaddr(uip_ipaddr_t *addr);

void 
ped_leave_network(void);

void
neighbor_state_changed(uip_ds6_nbr_t *nbr);

void
drop_route(uip_ds6_route_t *route);


extern pednet_instance_t curr_pednet_instance;
extern pednet_leaf_instance_t curr_pednet_leaf_instance;
extern pednet_er_instance_t curr_pednet_er_instance;
extern pednet_r_instance_t curr_pednet_r_instance;


struct pednet_driver
{
    char *name;
    void (* init)(void);
    int (* root_start)(void);
    int (* node_is_ER)(void);
    int (* node_is_R)(void);
    int (* node_is_leaf)(void);
    void (* set_prefix)(uip_ipaddr_t *prefix, uip_ipaddr_t *iid);
    int (* get_er_ipaddr)(uip_ipaddr_t *ipaddr);
    void (* leave_network)(void);
    int (* node_has_joined)(void);
    int (* node_is_reachable)(void);
    void (* link_callback)(const linkaddr_t *addr, int status, int numtx);
    void (* neighbor_state_changed)(uip_ds6_nbr_t *nbr);
    void (* drop_route)(uip_ds6_route_t *route);

};




#endif