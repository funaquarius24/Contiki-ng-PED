/*****************************************************************************
 * 
 * 
 * 
 * 
 * 
 * ****************************************************************************/


#include "contiki.h"
#include "contiki-net.h"


#include "net/pednet/pednet.h"
#include "net/pednet/pednet-conf.h"
#include "net/pednet/pednet-const.h"
#include "net/pednet/pednet-types.h"
#include "net/pednet/pednet-timers.h"
#include "net/pednet/pednet-leaf.h"
#include "net/pednet/pednet-routing.h"

#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-sr.h"


/* Log configuration */
#include "sys/log.h"
#define LOG_MODULE "PED"
#define LOG_LEVEL LOG_LEVEL_PED

// hhhhh
pednet_instance_t curr_pednet_instance;
pednet_leaf_instance_t curr_pednet_leaf_instance;

static void r_addr_paraam_input(void);
static void node_new_ack_input(void);
static void node_unreachable_input(void);

PED_HANDLER(r_addr_paraam_handler, PED_MESSAGES, PED_CODE_ROUTER_NEW, r_addr_paraam_input);
PED_HANDLER(node_new_ack_handler, PED_MESSAGES, PED_FAIL_NODE_FAILED, node_new_ack_input);
PED_HANDLER(node_unreachable_handler, PED_FAIL_DETECT, PED_FAIL_NODE_MOBILE, node_unreachable_input);



void 
ped_leaf_init(void){
  LOG_INFO("LEAF INIT REACHED");

  ped_timers_init();
  //curr_pednet_instance = NULL;
  ped_register_input_handler(&r_addr_paraam_handler);
  ped_register_input_handler(&node_new_ack_handler);
  ped_register_input_handler(&node_unreachable_handler);

    
}

void 
r_addr_paraam_input()
{

}
void
node_new_ack_input(){}
void
node_unreachable_input(){}

void
set_global_address(uip_ipaddr_t *prefix, uip_ipaddr_t *iid)
{
  static uip_ipaddr_t root_ipaddr;
  const uip_ipaddr_t *default_prefix;
  int i;
  uint8_t state;

  default_prefix = uip_ds6_default_prefix();

  /* Assign a unique local address (RFC4193,
     http://tools.ietf.org/html/rfc4193). */
  if(prefix == NULL) {
    uip_ip6addr_copy(&root_ipaddr, default_prefix);
  } else {
    memcpy(&root_ipaddr, prefix, 8);
  }
  if(iid == NULL) {
    uip_ds6_set_addr_iid(&root_ipaddr, &uip_lladdr);
  } else {
    memcpy(((uint8_t*)&root_ipaddr) + 8, ((uint8_t*)iid) + 8, 8);
  }

  uip_ds6_addr_add(&root_ipaddr, 0, ADDR_AUTOCONF);

  LOG_INFO("IPv6 addresses:\n");
  for(i = 0; i < UIP_DS6_ADDR_NB; i++) {
    state = uip_ds6_if.addr_list[i].state;
    if(uip_ds6_if.addr_list[i].isused &&
       (state == ADDR_TENTATIVE || state == ADDR_PREFERRED)) {
      LOG_INFO("-- ");
      LOG_INFO_6ADDR(&uip_ds6_if.addr_list[i].ipaddr);
      LOG_INFO_("\n");
    }
  }
}

/*---------------------------------------------------------------------------*/
void
ped_leaf_set_prefix(uip_ipaddr_t *prefix, uip_ipaddr_t *iid)
{
  static uint8_t initialized = 0;

  if(!initialized) {
    set_global_address(prefix, iid);
    initialized = 1;
  }
}
/*---------------------------------------------------------------------------*/
int
ped_leaf_start(void)
{
  //struct uip_ds6_addr *root_if;
  //int i;
  //uint8_t state;
  //uip_ipaddr_t *ipaddr = NULL;

  //ped_leaf_set_prefix(NULL, NULL);

  return 0;

  
}



const struct pednet_driver pednet_leaf_routing_driver = {
    "PEDNET_LEAF",
    ped_leaf_init,
    ped_leaf_start,
    ped_node_is_er,
    ped_node_is_r,
    ped_node_is_leaf,
    ped_leaf_set_prefix,
    ped_get_er_ipaddr,
    ped_leave_network,
    ped_node_has_joined,
    ped_node_is_reachable,
    ped_link_callback,
    neighbor_state_changed,
    drop_route,

};
