#ifndef PEDNET_LEAF_H
#define PEDNET_LEAF_H



void ped_leaf_init(void);
void ped_node_new_output(uip_ipaddr_t *addr);



















#endif
