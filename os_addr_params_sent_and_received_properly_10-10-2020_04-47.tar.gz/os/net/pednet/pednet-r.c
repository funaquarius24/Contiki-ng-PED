/*****************************************************************************
 * 
 * 
 * 
 * 
 * 
 * ****************************************************************************/


#include "contiki.h"
#include "contiki-net.h"


#include "net/pednet/pednet.h"
#include "net/pednet/pednet-conf.h"
#include "net/pednet/pednet-const.h"
#include "net/pednet/pednet-types.h"
#include "net/pednet/pednet-timers.h"
#include "net/pednet/pednet-r.h"
#include "net/pednet/pednet-routing.h"

#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-sr.h"
#include "net/ipv6/uip.h"
#include "sys/node-id.h"

/* Log configuration */
#include "sys/log.h"
#define LOG_MODULE "PED"
#define LOG_LEVEL LOG_LEVEL_PED

// hhhhh
pednet_instance_t curr_pednet_instance;
pednet_r_instance_t curr_pednet_r_instance;
er_addr_param_t er_addr_param_structure;
//uip_ds6_addr_t *lladdr;

static void node_new_input(void);
static void router_new_ack_input(void);
static void er_addr_param_input(void);
static void node_alive_input(void);
static void node_unreachable_input(void);
static void node_mobile_input(void);
static void router_unreachable_input(void);

PED_HANDLER(node_new_handler, PED_MESSAGES, PED_CODE_NODE_NEW, node_new_input);
PED_HANDLER(router_new_ack_handler, PED_MESSAGES, PED_CODE_ROUTER_NEW_ACK, router_new_ack_input);
PED_HANDLER(er_addr_param_handler, PED_MESSAGES, PED_CODE_ER_ADDR_PARAM, er_addr_param_input);
PED_HANDLER(node_alive_handler, PED_FAIL_DETECT, PED_FAIL_NODE_ALIVE, node_alive_input);
PED_HANDLER(node_unreachable_handler, PED_FAIL_DETECT, PED_FAIL_NODE_UNREACHABLE, node_unreachable_input);
PED_HANDLER(node_mobile_handler, PED_FAIL_DETECT, PED_FAIL_NODE_MOBILE, node_mobile_input);
PED_HANDLER(router_unreachable_handler, PED_FAIL_DETECT, PED_FAIL_ROUTER_UNREACHABLE, router_unreachable_input);



void 
ped_r_init(void){
  LOG_INFO("R INIT REACHED \n");

  ped_timers_init();
  //curr_pednet_instance = NULL;
  ped_register_input_handler(&node_new_handler);
  ped_register_input_handler(&router_new_ack_handler);
  ped_register_input_handler(&er_addr_param_handler);
  ped_register_input_handler(&node_alive_handler);
  ped_register_input_handler(&node_unreachable_handler);
  ped_register_input_handler(&node_mobile_handler);
  ped_register_input_handler(&router_unreachable_handler);

    
}

void
ped_r_addr_param_output(uip_ipaddr_t *addr){
  LOG_INFO("ped_r_addr_param_output ID: %u \n", node_id);

  uip_ds6_addr_t *lladdr = uip_ds6_get_link_local(-1);
  uip_ipaddr_t* local_addr = &lladdr->ipaddr;
  
  unsigned char *buffer;

  PED_PACKET_BUF -> type = PED_MESSAGES;
  PED_PACKET_BUF -> icode = PED_CODE_ROUTER_ADDR_PARAM;
  
  memset(PED_PACKET_BUF -> reserved, 0, sizeof(PED_PACKET_BUF -> reserved));
  
  uip_create_linklocal_allnodes_mcast(&PED_PACKET_BUF -> destipaddr);
  PED_PACKET_BUF -> srcipaddr = *local_addr;

  r_addr_param_structure.cser = curr_pednet_instance.cser;
  r_addr_param_structure.csr = curr_pednet_instance.csr;
  r_addr_param_structure.router_uid = node_id;

  if(uip_is_addr_unspecified(&curr_pednet_instance.prefix)){
    uip_create_unspecified(&r_addr_param_structure.prefix);
    
  }
  
  buffer = PED_PACKET_PAYLOAD;
  memcpy(buffer, &r_addr_param_structure, sizeof(r_addr_param_t));
  ped_send(addr, PED_MESSAGES, PED_CODE_ROUTER_ADDR_PARAM, sizeof(r_addr_param_t));
  
}

void
ped_router_new_output(uip_ipaddr_t *addr){
  LOG_INFO("Router new output \n");
  uip_ds6_addr_t *lladdr = uip_ds6_get_link_local(-1);
  /* if(lladdr == NULL){
    LOG_INFO("NUUULLLLLLLLLLLL \n");
    return;
  } */
  uip_ipaddr_t* local_addr = &lladdr->ipaddr;
  
  unsigned char *buffer;

  PED_PACKET_BUF -> type = PED_MESSAGES;
  PED_PACKET_BUF -> icode = PED_CODE_ROUTER_NEW;
  
  memset(PED_PACKET_BUF -> reserved, 0, sizeof(PED_PACKET_BUF -> reserved));
  
  uip_create_linklocal_allrouters_mcast(&PED_PACKET_BUF -> destipaddr);
  PED_PACKET_BUF -> srcipaddr = *local_addr;
  
  buffer = PED_PACKET_PAYLOAD;
  buffer[0] = node_id;
  ped_send(addr, PED_MESSAGES, PED_CODE_ROUTER_NEW, 2);
}

void 
ped_node_new_ack_output(uip_ipaddr_t *addr){
  LOG_INFO("Node new ack output \n");
  uip_ds6_addr_t *lladdr = uip_ds6_get_link_local(-1);
  uip_ipaddr_t* local_addr = &lladdr->ipaddr;
  
  unsigned char *buffer;

  PED_PACKET_BUF -> type = PED_MESSAGES;
  PED_PACKET_BUF -> icode = PED_CODE_NODE_NEW_ACK;
  
  memset(PED_PACKET_BUF -> reserved, 0, sizeof(PED_PACKET_BUF -> reserved));
  
  PED_PACKET_BUF -> destipaddr = *addr;
  PED_PACKET_BUF -> srcipaddr = *local_addr;

  buffer = PED_PACKET_PAYLOAD;
  buffer[0] = buffer[1] = 0;
  ped_send(addr, PED_MESSAGES, PED_CODE_NODE_NEW_ACK, 2);
}

void 
router_new_ack_input()
{
  LOG_INFO("Router new ack received %u\n");
  router_new_delay_change(0);
}

void
node_alive_input(){}

static void
node_new_input(){
  //LOG_INFO("Node new received \n");
  uint8_t *buffer = PED_PACKET_PAYLOAD;
  uint16_t test = 0;

  memcpy(&test, buffer, sizeof(uint16_t));

  LOG_INFO("Node new received %u\n", test);

  if(!curr_pednet_r_instance.initialized){
    
    if(test > curr_pednet_instance.max_node_num){
      curr_pednet_instance.max_node_num = test;
    }
    ped_node_new_ack_output(&PED_PACKET_BUF->srcipaddr);
    
  }
  else
  {
    /* code */
  }
  
  
}
void
er_addr_param_input(){
  LOG_INFO("er_addr_param_input... ");
  uint8_t *buffer;
  buffer = PED_PACKET_PAYLOAD;
  uint16_t test_cser = 0;
  memcpy(&er_addr_param_structure, buffer, sizeof(er_addr_param_t));
  memcpy(&test_cser, buffer, sizeof(uint16_t));
  LOG_INFO("TEST CSER: %u", test_cser);
  LOG_INFO("recv cser: %u \n", er_addr_param_structure.cser);
  LOG_INFO("PREFIX: ");
  LOG_INFO_6ADDR(&er_addr_param_structure.prefix);
  LOG_INFO("\n");
  if(!curr_pednet_r_instance.configured){
    LOG_INFO("!configured \n");

    curr_pednet_instance.cser = er_addr_param_structure.cser;
    curr_pednet_instance.prefix = er_addr_param_structure.prefix;

    //calculate_node_address();

    curr_pednet_r_instance.configured = 1;
    
  }else{
    curr_pednet_instance.cser = er_addr_param_structure.cser;
    curr_pednet_instance.prefix = er_addr_param_structure.prefix;
  }
}

void
node_mobile_input(){

}
void
node_unreachable_input(){}
void
router_unreachable_input(){}

/*---------------------------------------------------------------------------*/
void
ped_r_set_prefix(uip_ipaddr_t *prefix, uip_ipaddr_t *iid)
{
  static uint8_t initialized = 0;

  if(!initialized) {
    ped_set_global_address(prefix, iid);
    initialized = 1;
  }
}
/*---------------------------------------------------------------------------*/
int
ped_r_start(void)
{
  //struct uip_ds6_addr *root_if;
  //int i;
  //uint8_t state;
  //uip_ipaddr_t *ipaddr = NULL;

  //ped_r_set_prefix(NULL, NULL);

  return 0;

  
}

const struct pednet_driver pednet_r_routing_driver = {
    "PEDNET_R",
    ped_r_init,
    ped_r_start,
    ped_node_is_er,
    ped_node_is_r,
    ped_node_is_leaf,
    ped_r_set_prefix,
    ped_get_er_ipaddr,
    ped_leave_network,
    ped_node_has_joined,
    ped_node_is_reachable,
    ped_link_callback,
    neighbor_state_changed,
    drop_route,

};
